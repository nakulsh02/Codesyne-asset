Future Cursor
=============

Author: yeyushengfan258

Notes:
This is an x-cursor theme inspired by macOS and based on capitaine-cursors.

This animated cursor set contains 47 cursors.

Files included:
  - EWResize.cur
  - Alternate.cur
  - EWResize.cur
  - EWResize.cur
  - EWResize.cur
  - Link.cur
  - Move.cur
  - Move.cur
  - Help.cur
  - Move.cur
  - Move.cur
  - NEResize.cur
  - NEResize.cur
  - NEResize.cur
  - Normal.cur
  - NSResize.cur
  - NSResize.cur
  - NSResize.cur
  - NotAllowed.cur
  - NSResize.cur
  - NotAllowed.cur
  - NWResize.cur
  - NWResize.cur
  - NWResize.cur
  - Text.cur
  - Precision.cur
  - cell.cur
  - alias.cur
  - color-picker.cur
  - context-menu.cur
  - copy.cur
  - down-arrow.cur
  - draft.cur
  - dnd-no-drop.cur
  - left-arrow.cur
  - pencil.cur
  - right-arrow.cur
  - right_ptr.cur
  - up-arrow.cur
  - vertical-text.cur
  - pirate.cur
  - wayland-cursor.cur
  - x-cursor.cur
  - zoom-in.cur
  - zoom-out.cur
  - Wait.ani
    - Wait_32-48-64.ani (multisize: 32, 48, 64px)
  - AppStarting.ani
    - AppStarting_32-48-64.ani (multisize: 32, 48, 64px)

Installation:
  1. Unzip this folder
  2. Right-click install.inf and choose 'Install'
     (Windows 11: choose 'Show more options' first)
  3. Open Mouse Properties, then its Pointers tab:
     - Search: click the search box on the taskbar (or Start),
       type  main.cpl  and press Enter
     - Or Run box: press the Windows key + R, type  main.cpl  and press Enter
     - Or Settings: Settings > Bluetooth & devices > Mouse >
       Additional mouse settings (older Windows: Control Panel > Mouse)
  4. Select 'Future Cursor 246326' from the Scheme dropdown if it is not already selected
  5. Click OK

Downloaded from Cursors-4U.com
https://www.cursors-4u.com
